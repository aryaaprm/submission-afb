package com.dicoding.kotlin

class Memek(val name : String, val age : Int)

data class DataUser(val name : String, val age : Int)

fun main(){
    val memek = Memek("nrohmen", 17)
    val dataUser = DataUser("nrohmen", 17)

    println(memek)
    println(dataUser.name)
}

