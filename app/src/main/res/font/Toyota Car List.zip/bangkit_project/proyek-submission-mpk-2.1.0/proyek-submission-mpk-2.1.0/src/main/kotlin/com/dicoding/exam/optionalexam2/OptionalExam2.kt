package com.dicoding.exam.optionalexam2

// TODO
fun minAndMax(number: Int): Int {
    val numbers = number.toString().map { it.toString().toInt() }

    val minNumbers = numbers.minOrNull() ?: 0
    val maxNumbers = numbers.maxOrNull() ?: 0

    return minNumbers + maxNumbers
}
