package com.dicoding.exam.optionalexam3

// TODO
fun manipulateString(str: String, int: Int): String {
    val numberFinder = "\\d+".toRegex()
    val number = numberFinder.find(str)

    return if (number != null) {
        val numberInString = number.value.toInt() * int
        str.replace(number.value, numberInString.toString())
    } else {
        str + int
    }
}
