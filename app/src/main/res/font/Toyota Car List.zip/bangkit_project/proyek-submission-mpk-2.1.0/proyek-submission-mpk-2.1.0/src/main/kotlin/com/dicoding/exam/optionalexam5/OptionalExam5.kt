package com.dicoding.exam.optionalexam5

// TODO
val concatString = String::plus
