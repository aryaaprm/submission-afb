package com.dicoding.exam.optionalexam4

// TODO
fun getMiddleCharacters(string: String): String {
    val stringLength = string.length

    return if (stringLength % 2 == 0) {
        string.substring((stringLength / 2) - 1, (stringLength / 2) + 1)
    } else {
        string.substring(stringLength / 2, (stringLength / 2) + 1)
    }
}
